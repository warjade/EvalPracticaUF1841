const numbers = [0,1,2,4,5,9,3,6,7,8];
let counter = 0
console.log(counter)
// Put your code here
for (let item of numbers) {
    console.log(numbers[counter]);
    counter = counter+1
    // Put your code here
}
console.log(counter)
console.log(/* Put your code here */)