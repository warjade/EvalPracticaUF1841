const numbers = [0,1,5,2,7,5,0,0,9,5,5,6];
let counter = 0;

// Put your code here
const minimun = 5

for (item of numbers) {
    if (item >= minimun){
        console.log(`${item} is greater or equal to ${minimun}`)
    }
}
console.log(counter)