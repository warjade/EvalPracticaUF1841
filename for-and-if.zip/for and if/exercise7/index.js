const numbers = ["Frodo","Gandalf","Turin","Sauron","Saruman","Bilbo"];

// Put your code here

console.log("Simple")
for (let idx = 3; idx < 6 ; idx++) {
    console.log(idx);
}