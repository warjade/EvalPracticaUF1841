// Put your code here
for (let outer = 0; outer < 10 ; outer++) {
    for (let inner = 0; inner < 1; inner++ ){
        console.log(`Outer: ${outer}, Inner: ${inner}`);
    }
}