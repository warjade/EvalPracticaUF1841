let y=0;
function sumaUno (x){
    x= x+1;
    return x;
}
y=sumaUno(y)
console.log(x)
