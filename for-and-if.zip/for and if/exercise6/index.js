const mix = [undefined,22,"1",4,3,"5",7,NaN,8,"9","12",11,null];
let strings = [];
let numbers = [];
for (let item of mix) {
    console.log("item:", item);
    if (typeof thisVariable === "string") {
        console.log
    }
    strings.push("")
    
    console.log("item:", item);
    if (typeof thisVariable === numbers) {
        console.log        
    }
    numbers.push(1)
}

console.log("Strings:",strings,"Numbers:",numbers)