# Different nested for
* Revisa y comprende el contenido de [example.js](example.js).
* Aplicando los conceptos expuestos en example.js, completa el código de [index.js](index.js) para que imprima en la pantalla las tablas de multiplicar.
* Soluciona insertando el código necesario en el lugar indicado por el comentario.

